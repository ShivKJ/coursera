
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private static final double CONFIDENCE_95 = 1.96;

    private final int      trials;
    private final double[] outcome;

    public PercolationStats(int n, int trials) {
        numberGreaterThanZero(n);
        this.trials = numberGreaterThanZero(trials);
        this.outcome = process(n, trials);
    }

    public double mean() {
        return StdStats.mean(outcome);
    }

    public double stddev() {
        return StdStats.stddev(outcome);
    }

    public double confidenceLo() {
        return mean() - CONFIDENCE_95 * StdStats.stddev(outcome) / Math.sqrt(trials);
    }

    public double confidenceHi() {
        return mean() + CONFIDENCE_95 * StdStats.stddev(outcome) / Math.sqrt(trials);
    }

    private static double[] process(int n, int trials) {
        double[] out = new double[trials];

        for (int i = 0; i < trials; i++)
            out[i] = process(n);

        return out;
    }

    private static double process(int n) {
        int blocks = n * n;
        Percolation p = new Percolation(n);

        int[] sites = StdRandom.permutation(blocks);
        int index = 0;

        while (!p.percolates()) {
            int s = sites[index++];
            int i = 1 + s / n;
            int j = 1 + s % n;

            p.open(i, j);
        }

        return (1. * p.numberOfOpenSites()) / blocks;

    }

    private static int numberGreaterThanZero(int n) {
        if (n < 1)
            throw new IllegalArgumentException();

        return n;
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]), trials = Integer.parseInt(args[1]);

        PercolationStats stats = new PercolationStats(n, trials);
        StdOut.printf("%-23s = %f\n", "mean", stats.mean());
        StdOut.printf("%-23s = %f\n", "stddev", stats.stddev());
        StdOut.printf("%-23s = [%f, %f]\n", "95% confidence interval", stats.confidenceLo(), stats.confidenceHi());

    }
}
