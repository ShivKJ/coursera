
import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] items;
    private int    size;

    public RandomizedQueue() {
        this.items = (Item[]) new Object[10];
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;

    }

    public int size() {
        return size;
    }

    public void enqueue(Item t) {
        if (t == null)
            throw new IllegalArgumentException();

        if (size == items.length)
            ensureSize(2 * size);

        items[size++] = t;
    }

    public Item dequeue() {
        if (isEmpty())
            throw new NoSuchElementException();

        if (size <= items.length / 4 && size > 10)
            ensureSize(2 * size);

        int index = StdRandom.uniform(size);

        Item out = items[index];

        items[index] = items[size - 1];
        items[--size] = null;

        return out;

    }

    public Item sample() {
        if (isEmpty())
            throw new NoSuchElementException();

        return items[StdRandom.uniform(size)];
    }

    private void ensureSize(int capacity) {
        Item[] newArray = (Item[]) new Object[capacity];
        System.arraycopy(items, 0, newArray, 0, size);
        items = newArray;
    }

    @Override
    public Iterator<Item> iterator() {
        Item[] newItems = (Item[]) new Object[size];
        System.arraycopy(items, 0, newItems, 0, size);

        StdRandom.shuffle(newItems);

        return new Iterator<Item>() {
            int index = 0;

            @Override
            public boolean hasNext() {
                return index < newItems.length;
            }

            @Override
            public Item next() {
                if (!hasNext())
                    throw new NoSuchElementException();

                return newItems[index++];
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public static void main(String[] args) {
        RandomizedQueue<Integer> queue = new RandomizedQueue<>();

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);

        for (int i = 0; i < 10; i++)
            StdOut.println(queue.sample());

        StdOut.println("========================");
        Iterator<Integer> iterator = queue.iterator();

        while (iterator.hasNext())
            StdOut.println(iterator.next());

        StdOut.println("========================");

        while (!queue.isEmpty())
            StdOut.println(queue.dequeue());
    }

}
