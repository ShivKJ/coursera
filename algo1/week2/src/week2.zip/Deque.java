
import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.StdOut;

public class Deque<Item> implements Iterable<Item> {
    private Node<Item> front, back;
    private int        size;

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void addFirst(Item t) {
        validateData(t);

        Node<Item> n = new Node<>(t);

        if (isEmpty())
            front = back = n;
        else {
            n.next = front;
            front.prev = n;
            front = n;
        }

        size++;
    }

    public void addLast(Item t) {
        validateData(t);

        Node<Item> n = new Node<>(t);

        if (isEmpty())
            front = back = n;
        else {
            n.prev = back;
            back.next = n;
            back = n;
        }

        size++;
    }

    private static void validateData(Object data) {
        if (data == null)
            throw new IllegalArgumentException();
    }

    private void validateRemoval() {
        if (isEmpty())
            throw new NoSuchElementException();
    }

    public Item removeFirst() {
        validateRemoval();

        Item out = front.data;
        Node<Item> next = front.next;

        if (next != null) {
            next.prev = null;
            front.next = null;
        } else
            back = null;

        front = next;

        size--;

        return out;
    }

    public Item removeLast() {
        validateRemoval();

        Item out = back.data;

        Node<Item> prev = back.prev;

        if (prev != null) {
            prev.next = null;
            back.prev = null;
        } else
            front = null;

        back = prev;

        size--;

        return out;
    }

    @Override
    public Iterator<Item> iterator() {
        return new Iterator<Item>() {
            Node<Item> curr = front;

            @Override
            public boolean hasNext() {
                return curr != null;
            }

            @Override
            public Item next() {
                if (curr == null)
                    throw new NoSuchElementException();

                Item out = curr.data;
                curr = curr.next;
                return out;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    private final static class Node<T> {
        T       data;
        Node<T> prev, next;

        Node(T data) {
            this.data = data;
        }

    }

    public static void main(String[] args) {
        Deque<Integer> deque = new Deque<>();
        deque.addFirst(1);
        deque.addFirst(2);
        deque.addFirst(3);

        deque.addLast(10);
        deque.addLast(20);

        deque.forEach(StdOut::println);

        StdOut.println("=================");

        while (!deque.isEmpty())
            StdOut.println(deque.removeLast());

        deque = new Deque<>();
        deque.addFirst(1);
        deque.addFirst(2);
        deque.addFirst(3);

        deque.addLast(10);
        deque.addLast(20);

        Iterator<Integer> iterator = deque.iterator();

        StdOut.println("=============");

        while (iterator.hasNext())
            StdOut.println(iterator.next());

    }
}
