
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public final class FastCollinearPoints {
    private final static int MIN_PT_ON_LINE = 4;

    private final Point[]      pts;
    private LineSegment[]      lineSegments;
    private final List<String> containedSegments;

    public FastCollinearPoints(Point[] points) {
        this.pts = checkInput(points);
        this.containedSegments = new LinkedList<>();
        process();
    }

    private static Point[] checkInput(Point[] points) {
        if (points == null || points.length < MIN_PT_ON_LINE)
            throw new IllegalArgumentException();

        points = points.clone();

        for (Point point : points)
            if (point == null)
                throw new IllegalArgumentException();

        Arrays.sort(points);

        for (int i = 0; i < points.length - 1; i++)
            if (points[i].compareTo(points[i + 1]) == 0)
                throw new IllegalArgumentException();

        return points;
    }

    private void process() {
        List<LineSegment> output = new LinkedList<>();

        for (int i = 0; i < pts.length; i++) {
            Point p = pts[i];

            Point[] points = pts.clone();
            Arrays.sort(points, p.slopeOrder());

            Collection<Point> sameSlopePoints = new ArrayList<>(MIN_PT_ON_LINE);
            double slope = p.slopeTo(points[1]), s = slope;

            for (int j = 1; j < points.length; sameSlopePoints.clear(), slope = s) {

                do
                    sameSlopePoints.add(points[j++]);
                while (j < points.length && slope == (s = p.slopeTo(points[j])));

                if (sameSlopePoints.size() >= MIN_PT_ON_LINE - 1) {
                    sameSlopePoints.add(p);

                    LineSegment ls = new LineSegment(Collections.min(sameSlopePoints), Collections.max(sameSlopePoints));
                    String key = ls.toString();
                    
                    if (!containedSegments.contains(key)) {
                        output.add(ls);
                        containedSegments.add(key);
                    }
                }
            }
        }

        this.lineSegments = output.toArray(LineSegment[]::new);
    }

    public int numberOfSegments() {
        return lineSegments.length;

    }

    public LineSegment[] segments() {
        return lineSegments.clone();
    }

    public static void main(String[] args) {
        In in = new In("data/equidistant.txt");
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
//        StdDraw.enableDoubleBuffering();
//        StdDraw.setXscale(0, 32768);
//        StdDraw.setYscale(0, 32768);
//        for (Point p : points) {
//            p.draw();
//        }
//        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);

        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
//            segment.draw();
        }
//        StdDraw.show();
    }
}
